Le modèle du domaine et les différents diagrammes de séquence
système se trouvent dans les dossiers "Design Logiciel" et "Modèle de 
conception du domaine".
Il y a pour chaque diagramme un format .vpp et un format .png qui sert
à afficher les images dans le rapport qui est un fichier HTML.